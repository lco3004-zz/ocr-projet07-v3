/*
 *
 * Dto uilis� en lien avec le service Batch
 *
 */


package fr.ocr.application.ouvrage;

import lombok.Value;

@Value
public class OuvrageCrudDtoBatch {

     String titre; String auteur;

}