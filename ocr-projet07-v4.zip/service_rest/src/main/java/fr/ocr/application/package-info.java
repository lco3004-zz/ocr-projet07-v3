@org.springframework.lang.NonNullApi
package fr.ocr.application;