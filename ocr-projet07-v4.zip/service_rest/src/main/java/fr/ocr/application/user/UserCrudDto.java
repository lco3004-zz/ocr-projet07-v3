package fr.ocr.application.user;

import lombok.Value;

@Value
public class UserCrudDto  {

    private String username;
    private String email;

}
