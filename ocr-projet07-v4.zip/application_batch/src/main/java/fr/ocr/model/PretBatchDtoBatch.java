package fr.ocr.model;

import lombok.Data;

import java.util.Date;

@Data
public class PretBatchDtoBatch  {

     int userIduser;
     int ouvrageIdouvrage;
     Date dateEmprunt;
}
