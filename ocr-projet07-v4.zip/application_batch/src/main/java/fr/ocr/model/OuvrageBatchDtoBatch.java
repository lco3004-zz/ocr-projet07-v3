package fr.ocr.model;

import lombok.Data;



@Data
public class OuvrageBatchDtoBatch  {

    String titre;
    String auteur;

}