package fr.ocr.model;

import lombok.Data;


@Data
public class UserBatchDtoBatch  {
    private String username;
    private String email;
}
